public class Animal {
    public double peso;
    public boolean sujo;


    public Animal(double peso, boolean sujo) {
        this.peso = peso;
        this.sujo = sujo;
    }

    public void comer(double pesoComida){
        this.peso += pesoComida;
        System.out.println("Peso do pet: " + peso);
    }

    public void banhar(){
        this.sujo = false;
        System.out.println("Ta limpinho");
    }
}
