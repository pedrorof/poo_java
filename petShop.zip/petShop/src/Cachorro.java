public class Cachorro extends Animal{

    private String raca = "Cachorro";

    public Cachorro(double peso, boolean sujo) {
        super(peso, sujo);
    }

    @Override
    public String toString() {
        return "Cachorro{" +
                "peso=" + peso +
                ", sujo=" + sujo +
                ", raca='" + raca + '\'' +
                '}';
    }
}
