public class Gato extends Animal{

    private String raca = "Gato";

    public Gato(double peso, boolean sujo) {
        super(peso, sujo);
    }

    @Override
    public String toString() {
        return "Gato{" +
                "peso=" + peso +
                ", sujo=" + sujo +
                ", raca='" + raca + '\'' +
                '}';
    }
}
