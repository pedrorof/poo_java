public class Main {

    public static void main(String[] args) {
        PetShop petShop = new PetShop();
        Gato gato1 = new Gato(80.90, true);

        petShop.adicionarNovoPet(gato1);

        Cachorro cachorro1 = new Cachorro(10.99, true);

        petShop.adicionarNovoPet(cachorro1);

        petShop.alimentarPet(0, 10.9);
        petShop.alimentarPet(1, 20);

        petShop.banharPet(1);

        petShop.listarAnimais();

    }

}
