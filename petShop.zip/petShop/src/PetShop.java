import java.util.ArrayList;
import java.util.List;

public class PetShop {
    private List<Animal> animais;

    public PetShop() {
        this.animais = new ArrayList<>();
    }

    public void adicionarNovoPet(Animal novoAnimal){
        this.animais.add(novoAnimal);
    }

    public void alimentarPet(int posicao, double alimento){
        this.animais.get(posicao).comer(alimento);
    }

    public void banharPet(int posicao){
        this.animais.get(posicao).banhar();
    }

    public  void listarAnimais(){
        for (Animal animal : this.animais) {
            System.out.println(animal);
        }
    }
}
